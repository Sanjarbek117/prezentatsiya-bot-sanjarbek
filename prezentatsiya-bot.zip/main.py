from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes
from pptx import Presentation
from pptx.util import Inches

TOKEN = "BOT_TOKEN_PLACEHOLDER"  # <-- BU YERGA O'ZINGIZNING BOT TOKENINGIZNI YOZASIZ!

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Salom! Matn yuboring va men sizga prezentatsiya fayl yaratib beraman!")

async def create_presentation(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    prs = Presentation()
    slide_layout = prs.slide_layouts[1]
    slide = prs.slides.add_slide(slide_layout)
    title = slide.shapes.title
    body = slide.placeholders[1]
    title.text = "Prezentatsiya"
    body.text = text
    filename = "presentation.pptx"
    prs.save(filename)
    await update.message.reply_document(open(filename, "rb"))

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, create_presentation))
    app.run_polling()

if __name__ == '__main__':
    main()
